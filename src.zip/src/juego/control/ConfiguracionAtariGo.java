package juego.control;

public class ConfiguracionAtariGo {

}
